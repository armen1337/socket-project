from distutils.core import setup

setup(
    name='socket_project',
    packages=['socket_project'],
    version='0.1-alpha',
    description='My test library',
    author='armen1337',
    author_email='armen14102003@mail.ru',
    url='https://github.com/armen1337/socket-project',
    download_url='https://github.com/armen1337/socket-project/archive/refs/tags/v0.1-alpha.zip',
    keywords=[],
    classifiers=[],
)

# https://www.codementor.io/@arpitbhayani/host-your-python-package-using-github-on-pypi-du107t7ku
# https://medium.com/analytics-vidhya/how-to-create-a-python-library-7d5aea80cc3f
# https://github.com/armen1337/socket-project/archive/refs/tags/v0.1-alpha.tar.gz
